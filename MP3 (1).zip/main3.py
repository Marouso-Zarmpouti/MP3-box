from machine import Pin, PWM, I2C
import time
import ssd1306

# Buttons (using internal pull-ups)
play_btn = Pin(10, Pin.IN, Pin.PULL_UP)
next_btn = Pin(11, Pin.IN, Pin.PULL_UP)
prev_btn = Pin(12, Pin.IN, Pin.PULL_UP)
power_btn = Pin(13, Pin.IN, Pin.PULL_UP)

# Buzzer on GP16
buzzer = PWM(Pin(16))
def beep(freq, duration):
    buzzer.freq(freq)
    buzzer.duty_u16(30000)
    time.sleep(duration)
    buzzer.duty_u16(0)

# Screen setup
i2c = I2C(0, scl=Pin(5), sda=Pin(4))
oled = ssd1306.SSD1309_I2C(128, 64, i2c)

# Music data
songs = [
    "Song01.mp3",
    "Song02.mp3",
    "Song03.mp3",
    "Song04.mp3"
]

current_song = 0
playing = False

# Display function
def update_screen():
    oled.fill(0)
    oled.text("MP3 PLAYER", 20, 0)
    oled.text(songs[current_song], 0, 20)
    
    if playing:
        oled.text("Status: PLAY", 0, 40)
    else:
        oled.text("Status: PAUSE", 0, 40)
    
    oled.show()

# Initial screen
update_screen()

# Main loop
while True:
    # PLAY BTN
    if not play_btn.value():
        playing = not playing
        update_screen()
        beep(1000, 0.15)  # Μετακινήθηκε ΜΕΣΑ στο if
        time.sleep(0.3)   # Debounce delay

    # NEXT BTN
    if not next_btn.value():
        current_song += 1
        if current_song >= len(songs):
            current_song = 0
        update_screen()
        beep(1500, 0.15)
        time.sleep(0.3)

    # PREVIOUS BTN
    if not prev_btn.value():
        current_song -= 1  # Διορθώθηκε από = -1 σε -= 1
        if current_song < 0:
            current_song = len(songs) - 1
        update_screen()
        beep(700, 0.15)
        time.sleep(0.3)

    # POWER BTN
    if not power_btn.value():
        oled.fill(0)
        if playing:
            oled.text("Turning OFF", 10, 30) # Διορθώθηκε το ορθογραφικό
        else:
            oled.text("Turning ON", 10, 30)
        
        oled.show()
        beep(2000, 0.5)
        time.sleep(1.5)  # Περισσότερος χρόνος για να προλάβει ο χρήστης να διαβάσει το μήνυμα

        # Simulate power off status
        playing = False
        update_screen()
        
    time.sleep(0.05) # Μικρή καθυστέρηση για σταθερότητα του loop
